import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import { Subject, debounceTime, take } from 'rxjs';
import { Router } from '@angular/router';
import { Customer } from '../Model/Customer';
import { Console } from 'console';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrl: './table.component.css'
})
export class TableComponent implements OnInit{

 

  allCustomer: Array<Customer>=[];
  allCustomerList: Array<Customer>=[];
  product: any = 100;
  totalclothes: any = 1;




  searchText: string = '';
  customers: Customer[] = [];
  @Input() message: string = '';
  customer: any[]=[];
  offset: number = 0;
  pageSize: number = 4; // How many item you want to display in your page.
  customerObj={
    cid: "",
    cname: "",
    password: "", 
    email: "", 
    city: "" ,
    status: "", 
    dd: "",
    time: "",
    offset: 1,
    pagesize:10,
  }

  searchString = new Subject<string>();
 
  constructor(private service:ApiserviceService , private router:Router){
  }
  ngOnInit(): void {
    this.getAll();
    this.searchString.pipe(debounceTime(500)).subscribe((value: string) => {
      this.searchUsers(value);
      this.getCustomerList(true);


    });
  }

  getCustomerList(isAllClothe: boolean = false): void {
    let product: any = this.service.getCustomerByPage(this.offset - 1 < 0 ? 0 : this.offset - 1, this.pageSize);
   product.pipe(take(1)).subscribe((res: any) => {
    console.log('>>>>>>>>>', res)
      if (res && res?.product && Array.isArray(res?.product)) {
        this.allCustomer = res?.customer;
        this.allCustomerList = res?.customer;
        this.totalclothes = res?.totalclothes;
      }
    }, (err: any) => {
      console.log("Error");
    });
}


 
  
 

  onSearchInput(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;
    this.searchString.next(value);
    // this.searchUsers(value);
  }

  searchUsers(searchText: string) {
    this.service.searchCustomers(searchText).subscribe(
   (data: Customer[]) => {
     if (data.length > 0) {
      console.log('******',data.length);

       const adminId = localStorage.getItem('cname');
       console.log('******',adminId);
       this.customers = data;

      
     } else {
       this.customers = [];
     }
   },
   (error: any) => {
     console.error('Error searching customers', error);
   }
 );
}



  getAll():void{
    this.service.getAllCustomer().pipe(take(1)).subscribe((res:any) =>{
      this.customers=res;

    } )
  }

  deleteCustomer(Customer:any):void{

    this.service.deleteCustomerByCid(Customer?.cid).subscribe( (res:any)=>{
      console.log(">>>>>>>>>>>>>>",res);
      alert('Customer Deleted SucessFully');
      this.getAll();
    })

  }
  EditCustomer(Customer:any):void{
    console.log(Customer?.cid);
    this.router.navigate(['/addproduct'], { queryParams: {cid: Customer?.cid }}
    )
    console.log('update Customer');

  }

  getgetCustomerListByCategory(): void {
    this.offset = 0;
    this.totalclothes = 1;
    if (this.product === "100") {
      this.getCustomerList(true);
    } else {
      this.getCustomerList(false);
    }
  }

  onNextPageClick(pageOffSet: any): void {
    this.offset = pageOffSet;
    this.getCustomerList(this.product === 100 || this.product === "100");
  }

  onPreviousPageClick(pageOffSet: any): void {
    this.offset -= 1;
    this.getCustomerList(this.product === 100 || this.product === "100");
  }

  onFirstPageClick(pageOffSet: any): void {
    this.offset = 0;
    this.getCustomerList(this.product === 100 || this.product === "100");
  }

  onLastPageClick(pageOffSet: any): void {
    const lastPage = Math.ceil(this.totalclothes / this.pageSize);
    this.offset = lastPage;
    this.getCustomerList(this.product === 100 || this.product === "100");
  }
 
ngOnDestroy(): void {
  this.searchString.unsubscribe();

}


  }

