import { Component } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import { take } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product-item',
  templateUrl: './add-product-item.component.html',
  styleUrl: './add-product-item.component.css'
})
export class AddProductItemComponent {
  pid: number = 0;
  pName: string = ' ';
  pPrice:number=0;
  status:boolean=false;
  pImage!:string


  errorMessage: String = ' ';
  errorMessage2: String = ' ';
  errorMessage3: String = ' ';
  errorMessage4: String = ' ';
  errorMessage5: String = ' ';


  constructor(
    private service: ApiserviceService,
    private router: Router
  ) {}

  submit(): void {

    if (this.pid === null) {
      alert('pid is Required');
      this.errorMessage = 'pid is Required';
     return;
    }else  if ((this.pName === ' ')) {
      alert('Name is Required');
      this.errorMessage2 = 'Name is Required';
     return;
    }

     else if (this.pPrice <= 100) {
     alert('Price is starting 100 Rs ');
     this.errorMessage3 = 'Price is starting 100 Rs';
      return;
    } else if(this.pImage === null){
      alert('pImage is Required');
      this.errorMessage4='pImage is Required';


    }
  
    else if (this.status === null ) {
     alert('Status is Required');
     this.errorMessage5 = 'Status is Required';
    return; 
    }

    console.log('ffffff');
    const body: any = {
      pid: this.pid,
      pname: this.pName,
      pPrice: this.pPrice,
      status: this.status,
      pImage: this.pImage

    };
    this.service.addProduct(body).pipe(take(1)).subscribe((res: any)=> {
      if (res?.pid) {
        alert("Product Added Successfully");
        this.router.navigate(['/products']);
      }
    });
  }
}
