import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import { take } from 'rxjs';
import { Product } from '../Model/Product';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import { Script } from 'vm';


@Component({
  selector: 'app-listproduct',
  templateUrl: './listproduct.component.html',
  styleUrl: './listproduct.component.css',
})


export class ListproductComponent implements OnInit{

myVideo: any=' ';
  allCustomerProduct: Array<Product> = [];
  constructor(
    private service: ApiserviceService
  ) {

  }
  
  ngOnInit(): void {
    this.getProduct();
   
  }

 


  
  getProduct(){
  this.service.getAllProduct().pipe(take(1)).subscribe((res:any) =>{
    if (res && Array.isArray(res)) {
      console.log('####', res);
      this.allCustomerProduct = res;
    }
  });
}

  deleteProduct(Product:any):void{

    this.service.deleteProductByPid(Product?.pid).subscribe((res:any)=>{
      
        console.log(">>>>>>>>>>>",res);
        alert('Product Deleted sucessfully');
        this.getProduct();
    })
  }
 
  
  // Pause and play the video, and change the button text
   myFunction() {

    if(this.myVideo.Pause){
      this.myVideo();   
  }else{
    this.myVideo.pause();

  }
}
}
