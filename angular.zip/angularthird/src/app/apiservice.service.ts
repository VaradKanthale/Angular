import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Customer } from './Model/Customer';

@Injectable({
  providedIn: 'root',
})
export class ApiserviceService {
  private URL = 'http://localhost:8080';

  constructor(private service: HttpClient ,private router:Router ) {}

  navigatetoLink(args:any):void{
    this.router.navigate(['/'+args]);

  }

  getAllCustomer(): Observable<any> {
    // return this.service.get(this.URL + /Api/GetAll`);
    return this.service.get(this.URL + '/Api/GetAll');
  }

  deleteCustomerByCid(cid: any): Observable<any> {
    return this.service.delete(this.URL + `/Api/${cid}`, {
      responseType: 'text',
    });
  }

  addUser(body: any): Observable<any> {
    return this.service.post(this.URL + '/Api/Customer', body);
  }

  getCustomerById(cid: any): Observable<any> {
    // return this.service.get(this.URL + /Api/GetAll`);
    return this.service.get(this.URL + '/Api/' + cid);
  }

  addProduct(body: any): Observable<any> {
    return this.service.post(this.URL + '/Api2', body);
  }

  getAllProduct(): Observable<any> {
    return this.service.get(this.URL + '/Api2');
  }
  deleteProductByPid(pid:any):Observable<any>{
    return this.service.delete(this.URL +`/Api2/${pid}`, {responseType : 'text' , });
  }

  updateCustomer(Customer:any):Observable<any>{
    return this.service.put(this.URL+`/Api/${Customer?.cid}`,Customer);
  }

  searchCustomers(searchText: string): Observable<Customer[]> {
    return this.service.get<Customer[]>(`${this.URL}/Api/search?searchText=${searchText}`);
  }

  getPagationOffsetAndSize(offset:any, pagesize:any):Observable<any>{
    return this.service.get(this.URL+`/Api/Page/` +offset+"/"+pagesize);

  }
  getCustomerByPage(pageno: any, pagesize: any):Observable<any>{
    return this.service.get(this.URL+"/Api/" + pageno + "/" + pagesize);
  }




}
