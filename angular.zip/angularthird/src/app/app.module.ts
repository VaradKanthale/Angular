import { AddProductItemComponent } from "./add-product-item/add-product-item.component";
import { AddProductComponent } from "./add-product/add-product.component";
import { ApiserviceService } from "./apiservice.service";
import { AppComponent } from "./app.component";
import { ListproductComponent } from "./listproduct/listproduct.component";
import { TableComponent } from "./table/table.component";
import { AppRoutingModule } from './app-routing.module copy';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {MatMenuModule} from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { DatePipe } from '@angular/common';
import { FilterPipe } from './filter.pipe';
import {  NgModel, NgModelGroup, ReactiveFormsModule } from "@angular/forms";
import {  BrowserModule} from "@angular/platform-browser";
import { NgModule } from "@angular/core";





//import {IonicModule} from '@ionic/angular';


@NgModule({
  declarations: [
    AppComponent,
    AddProductComponent,
    TableComponent,
    ListproductComponent,
    AddProductItemComponent,
   

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    NgModule,
    DatePipe,
    FilterPipe
    

    
  ],
  providers: [
    provideClientHydration(),
    ApiserviceService,
  ],
  
  bootstrap: [AppComponent]
})
export class AppModule {
}

function provideClientHydration(): import("@angular/core").Provider | import("@angular/core").EnvironmentProviders {
  throw new Error("Function not implemented.");
}
