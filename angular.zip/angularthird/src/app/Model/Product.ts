export class Product{
    pid!: number
    pname!: string
    pPrice!: number
    pImage!:string
    status!: boolean


}